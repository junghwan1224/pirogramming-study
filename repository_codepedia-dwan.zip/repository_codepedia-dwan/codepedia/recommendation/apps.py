from django.apps import AppConfig


class RecommendationConfig(AppConfig):
    name = 'recommendation'
