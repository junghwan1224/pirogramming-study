from django.shortcuts import get_object_or_404, render
from post.models import MainSubject, Link, SubTheme, MainTheme
from django.http import Http404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from .models import Link
import json
from .models import Link, Likes
from .forms import PostForm


# Create your views here.



# def post_list(request):
#     qs = Main_subject.objects.all()
#     q = request.GET.get('q', '')
#     if q:
#         qs = qs.filter(title__icontains=q)
#     return render(request, 'post/post1.html', {
#         'post_list': qs,
#     })

def post_list(request, id=0):
    main_subjects = MainSubject.objects.all()
    search_keyword = request.GET.get('keyword', '')
    if search_keyword:
        main_subjects = main_subjects.filter(title__icontains=search_keyword)

    return render(request, 'post/post_list.html', {
        'main_subjects': main_subjects,
        'keyword': search_keyword,
    })

def post_content(request, id):
    post=get_object_or_404(MainTheme, id=id)
    main_subjects = MainSubject.objects.all()
    search_keyword = request.GET.get('keyword', '')
    if search_keyword:
        main_subjects = main_subjects.filter(title__icontains=search_keyword)

    return render(request,'post/layout.html',{
        'main_theme' : post,
        'main_subjects': main_subjects,
        'keyword': search_keyword,
    })







@login_required # TODO: Ajax로 처리하기
def post_likes(request, pk):
    link = get_object_or_404(Link, pk=pk)
    # 중간자 모델 Like 를 사용하여, 현재 post와 request.user에 해당하는 Like 인스턴스를 가져온다.
    post_likes, post_likes_created = link.likes_set.get_or_create(user=request.user)



    return redirect('post:post_list')

