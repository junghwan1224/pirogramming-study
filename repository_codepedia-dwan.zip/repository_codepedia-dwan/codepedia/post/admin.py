from django.contrib import admin
from .models import MainSubject, MainTheme, SubTheme, Link, CommentOfLink, CommentOfComment, Comment, Likes


# Register your models here.
admin.site.register(MainSubject)
admin.site.register(MainTheme)
admin.site.register(SubTheme)
admin.site.register(CommentOfLink)
admin.site.register(CommentOfComment)
admin.site.register(Comment)

@admin.register(Link)
class LinkAdmin(admin.ModelAdmin):
    list_display = ['sub_theme', 'link']

class LikeInline(admin.TabularInline):
    model = Link.likes_user_set.through

    

