from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.db import models

import re

# Create your models here.
class MainSubject(models.Model):
    title = models.CharField(max_length=50, verbose_name="title", help_text="제목을 입력해 주세요. 최대 50자 내외.")
    content = models.TextField(blank="true", help_text="내용을 입력해 주세요.")
    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('blog:post_detail', args=[self.id])

    class Meta:
        ordering=['id']

class MainTheme(models.Model):
    def __str__(self):
        return self.title

    title = models.CharField(max_length=50, verbose_name="title", help_text="제목을 입력해 주세요. 최대 50자 내외.")
    content = models.TextField(blank="true", help_text="내용을 입력해 주세요.")
    main_subject = models.ForeignKey(MainSubject, related_name='post_main_theme_set')

class SubTheme(models.Model):
    def __str__(self):
        return self.title

    title = models.CharField(max_length=50, verbose_name="title", help_text="제목을 입력해 주세요. 최대 50자 내외.")
    content = models.TextField(blank="true", help_text="내용을 입력해 주세요.")
    main_theme = models.ForeignKey(MainTheme, related_name='post_sub_theme_set')

class Link(models.Model):
    title = models.CharField(max_length=100, verbose_name="link_title", default="")
    link = models.CharField(max_length=650, verbose_name="link")
    sub_theme = models.ForeignKey(SubTheme, related_name='post_link_set')
    view = models.IntegerField(default=0)
    like = models.IntegerField(default=0)
    unlike = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)
    likes_user_set = models.ManyToManyField(settings.AUTH_USER_MODEL,
                                           blank=True,
                                           related_name='likes_user_set',
                                           through='Likes')

class CommentOfLink(models.Model):
    link = models.ForeignKey(Link, related_name='post_comment_of_link_set')
    content = models.TextField()
    like = models.IntegerField()
    unlike = models.IntegerField()
    user = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)

class CommentOfComment(models.Model):
    link_comment = models.ForeignKey(CommentOfLink, related_name='post_comment_of_comment_set')
    content = models.TextField()
    like = models.IntegerField()
    unlike = models.IntegerField()
    user = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)

class Comment(models.Model):
    post = models.ForeignKey(MainSubject)
    author = models.CharField(max_length=20)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Likes(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL)
    link = models.ForeignKey(Link)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)