from django.shortcuts import get_object_or_404, render
from post.models import MainSubject, Link, SubTheme, MainTheme
from django.http import Http404


# Create your views here.



# def post_list(request):
#     qs = Main_subject.objects.all()
#     q = request.GET.get('q', '')
#     if q:
#         qs = qs.filter(title__icontains=q)
#     return render(request, 'post/post1.html', {
#         'post_list': qs,
#     })

def post_list(request, id=0):
    main_subjects = MainSubject.objects.all()
    search_keyword = request.GET.get('keyword', '')
    if search_keyword:
        main_subjects = main_subjects.filter(title__icontains=search_keyword)

    return render(request, 'post/post_list.html', {
        'main_subjects': main_subjects,
        'keyword': search_keyword,
    })

def post_content(request, id):

    post=get_object_or_404(MainTheme, id=id)
    main_subjects = MainSubject.objects.all()
    sub_theme=SubTheme.objects.all()
    link=Link.objects.all()
    search_keyword = request.GET.get('keyword', '')
    if search_keyword:
        main_subjects = main_subjects.filter(title__icontains=search_keyword)

    return render(request,'post/post_content.html',{

        'main_theme' : post,
        'main_subjects': main_subjects,
        'sub_theme': sub_theme,
        'search_keyword': search_keyword,
        'link':link,
    })

def favorite(request, id):
    favorite=get_object_or_404(Link, id=id)
    link= link.objects.all()
    return render(request,'post/urllink.html',{

        'link':link

    })


def link(request, id):

    post=get_object_or_404(MainTheme, id=id)
    main_subjects = MainSubject.objects.all()
    sub_theme=SubTheme.objects.all()
    link=Link.objects.all()
    search_keyword = request.GET.get('keyword', '')
    if search_keyword:
        main_subjects = main_subjects.filter(title__icontains=search_keyword)

    return render(request,'post/url_link.html',{

        'main_theme' : post,
        'main_subjects': main_subjects,
        'sub_theme': sub_theme,
        'search_keyword': search_keyword,
        'link':link,
    })