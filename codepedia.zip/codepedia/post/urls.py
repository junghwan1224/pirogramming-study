from django.conf.urls import url
from . import views

app_name = 'post'

urlpatterns = [
    url(r'^$', views.post_list, name='post_list'),

    url(r'^(?P<id>\d+)/$', views.post_content, name='post_content'),

    url(r'^(?P<id>\d+)/link/$', views.link, name='link'),

    url(r'^(?P<id>\d+)/$', views.favorite, name='favorite'),
]