from django.conf import settings
from django.conf.urls import url
from django.contrib.auth import views as auth_views
from . import views

app_name = 'accounts'

urlpatterns=[
    url(r'^signup/',views.signup,name='signup'),
    url(r'^login/$',views.login, name='login'),
    url(r'^profile/$',views.profile,name='profile'),
    url(r'^logout/$',auth_views.logout, name='logout', kwargs={'template_name':'accounts/login_form.html'}),
    url(r'^userrank/',views.userrank,name='userrank'),
    url(r'^activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',views.activate, name='activate'),
]