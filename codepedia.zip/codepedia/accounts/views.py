from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth.models import User
from .forms import UserForm, LoginForm, SignupForm
from django.contrib.auth.views import login as auth_login
from allauth.socialaccount.models import SocialApp
from allauth.socialaccount.templatetags.socialaccount import get_providers
from django.contrib.auth.models import User
from .models import UserProfiles
from .tokens import account_activation_token
from django.core.mail import EmailMessage
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
# Create your views here.

def signup(request):
    if request.method=='POST':
        form = UserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.save()
            current_site = get_current_site(request)
            message = render_to_string('acc_active_email.html', {
                'user':user,
                'domain':'localhost:8000',
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            mail_subject = 'Activate your blog account.'
            to_email = form.cleaned_data.get('username')
            subject='이메일 인증'
            email = EmailMessage(subject, message, to=[to_email])
            email.send()
            return HttpResponse('Please confirm your email address to complete the registration')

        else:
            return HttpResponse('사용자명이 이미 존재합니다.')
    else:
        form=SignupForm()
    return render(request,'accounts/signup_form.html',{
        'form':form,
        })

@login_required
def profile(request):
    return render(request,'accounts/profile.html')

def login(request):
    providers = []
    for provider in get_providers():
    # social_app속성은 provider에는 없는 속성입니다.
        try:
            provider.social_app = SocialApp.objects.get(provider=provider.id, sites=settings.SITE_ID)
        except SocialApp.DoesNotExist:
            provider.social_app = None
        providers.append(provider)
    return auth_login(request,
        authentication_form=LoginForm,
        template_name='accounts/login_form.html',
        extra_context={'providers': providers})

def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        auth_login(request, user)
        # return redirect('home')
        return HttpResponse('Thank you for your email confirmation. Now you can login your account.'    )
    else:
        return HttpResponse('Activation link is invalid!')
def userrank(request):
    userrank = User.objects.all()
    userrank2= UserProfiles.objects.all()
    ctx = {
        'user': userrank, 'user2':userrank2
    }
    return render(request, 'accounts/userrank.html', ctx)
