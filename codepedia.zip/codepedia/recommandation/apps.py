from django.apps import AppConfig


class RecommandationConfig(AppConfig):
    name = 'recommandation'
