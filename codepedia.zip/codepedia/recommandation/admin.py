from django.contrib import admin
from .models import Recommandations

# Register your models here.

@admin.register(Recommandations)
class PostAdmin(admin.ModelAdmin):
    list_display=['id', 'title', 'created_at', 'updated_at' ]


