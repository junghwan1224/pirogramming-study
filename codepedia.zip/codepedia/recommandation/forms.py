from django import forms
from .models import Recommandations
class RecommandationModelForm(forms.ModelForm):
    class Meta:
        model = Recommandations
        fields = ['title', 'content', 'email', 'URL']