from django.shortcuts import render, redirect
from .forms import RecommandationModelForm
# Create your views here.

def recommandation_create(request):
    form=RecommandationModelForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("/post/")
    else:
        form=RecommandationModelForm()
    content={
        'form':form,
    }
    response = render(request, 'recommandation/recommandation_list.html', content)
    return response