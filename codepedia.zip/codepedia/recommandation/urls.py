from django.conf.urls import url
from . import views

app_name = 'recommendation'

urlpatterns = [
    url(
        regex=r"^$",
        view=views.recommandation_create,
        name="recommandation_create"
    )
]